# Festival Drive — Original 3D Racing Game Source

This is an original racing-game codebase inspired by the general open-world festival-racing genre.
It does not contain Forza Horizon or other third-party source code/assets.

## Run
Serve this folder from a web server because Three.js is loaded from a CDN.
Open `index.html`.

## Main systems
- Three.js WebGL renderer
- Procedural island world
- Original procedural car models
- Four car profiles
- Driving/steering/nitro physics
- Race checkpoints
- Weather/day-night modes
- Camera switching
- Garage/car switching
- Credits saved with localStorage
- Keyboard and iPhone touch controls

## Expand
Add more car entries in `js/cars.js`, world systems in `js/world.js`, and race events in `js/races.js`.
